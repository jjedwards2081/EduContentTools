Game Data Folder
==================================================

This folder stores all your game data:
- World files (.mcworld)
- Uploaded documents (PDF, Word, PowerPoint)
- Language analysis
- Created resources (guides, workbooks, etc.)

Keep this folder with the application.
Backup this folder to preserve your data.
